#!/bin/bash

# -------------------------------------------------------------------------- #
# Copyright 2002-2012, OpenNebula Project Leads (OpenNebula.org)             #
#                                                                            #
# Licensed under the Apache License, Version 2.0 (the "License"); you may    #
# not use this file except in compliance with the License. You may obtain    #
# a copy of the License at                                                   #
#                                                                            #
# http://www.apache.org/licenses/LICENSE-2.0                                 #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

COPYRIGHT_HOLDER="2002-2012, OpenNebula Project Leads (OpenNebula.org)"
PACKAGE_NAME="OpenNebula"

find ../public/js -name \*.js > file_list.txt
echo "../../../../../sunstone/public/js/sunstone.js" >> file_list.txt
echo "../../../../../sunstone/public/js/sunstone-util.js" >> file_list.txt
echo "../public/customize/custom.js" >> file_list.txt
xgettext --from-code=utf-8 --copyright-holder="$COPYRIGHT_HOLDER" --package-name="$PACKAGE_NAME" --no-wrap --keyword=tr -L python -f file_list.txt -p .
mv messages.po messages.pot
rm file_list.txt