These XML Schemas define the XMLs returned by OpenNebula's XML-RPC API.

The included XML samples are not actual responses from OpenNebula, as it does
not include the headers (namespace, schema location).


To learn more, please read the API reference documentation at
http://opennebula.org/documentation:documentation:api

